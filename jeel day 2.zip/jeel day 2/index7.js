function myFunction()
{
    a=document.getElementsByName("myText")[0];
    alert(a,value);
}