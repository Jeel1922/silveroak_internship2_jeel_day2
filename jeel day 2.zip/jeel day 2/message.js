function myAlert(msg){
    if (confirm ("are you sure you want to display the message????")){
        alert(msg);
    }
    else{
        alert("Message not Displayed as user canceled Operation");
    }
}