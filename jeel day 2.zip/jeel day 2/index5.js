function myFunction()
{
    var txt = document.getElementById("my text");
    alert(txt.value);
}